'use strict';

class TellMe {
  constructor(maybe) {
    this.numbers = maybe;
  }
  getFirstNumber() {
    return this.numbers[0];
  }
  getNumberOdd(){
    
  };
}
